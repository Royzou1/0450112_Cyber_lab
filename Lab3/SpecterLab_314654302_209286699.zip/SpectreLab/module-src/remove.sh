#!/bin/bash
sudo rmmod ./labspectrekm.ko

