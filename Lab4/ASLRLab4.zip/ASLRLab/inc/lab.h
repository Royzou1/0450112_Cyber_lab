#ifndef LAB_PART1_H
#define LAB_PART1_H

#define PAGE_SIZE ((0x1000))

#endif // LAB_H
